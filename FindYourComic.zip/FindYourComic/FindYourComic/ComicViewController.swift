//
//  ComicViewController.swift
//  FindYourComic
//
//  Created by Marissa Kasenchak on 4/30/19.
//  Copyright © 2019 Marissa Kasenchak. All rights reserved.
//

import UIKit

class ComicViewController: UIViewController {
    var theComic: Comic?
    var myModel = myComicModel()
    
    @IBOutlet weak var ComicImage: UIImageView!
    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var IssuelLabel: UILabel!
    @IBOutlet weak var ISBNLabel: UILabel!
    @IBOutlet weak var Description: UILabel!
    @IBAction func SearchtheMap(_ sender: Any) {
        performSegue(withIdentifier: "showmap", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        TitleLabel.text = theComic?.title
        IssuelLabel.text = theComic?.issuenumber
        ISBNLabel.text = theComic?.isbn
        Description.text = theComic?.description
        ComicImage.image = theComic?.getbigPicture()
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "showmap"{
            _ = (segue.destination as? MapKitViewController)!
        }
    }
 

}
