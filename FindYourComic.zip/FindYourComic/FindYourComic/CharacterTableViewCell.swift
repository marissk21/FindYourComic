//
//  CharacterTableViewCell.swift
//  FindYourComic
//
//  Created by Marissa Kasenchak on 4/29/19.
//  Copyright © 2019 Marissa Kasenchak. All rights reserved.
//

import UIKit

class CharacterTableViewCell: UITableViewCell {

    @IBOutlet weak var CharacterImage: UIImageView!
    @IBOutlet weak var NameLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
