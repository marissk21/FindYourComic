//
//  GlobalConstants.swift
//  FindYourComic
//
//  Created by Marissa Kasenchak on 5/2/19.
//  Copyright © 2019 Marissa Kasenchak. All rights reserved.
//

import Foundation
class GlobalConstants {
    // API key for Marvel
    
    struct APIKey {
        static let MarvelAPIKey = "76a980d8955040ed12220e6b162523b4"
        static let MarvelprivateKey = "42d44e593bfe3b2628121fa2cb64c7728d87d387"
        static let ts = Date()
        static let dateformatter = DateFormatter()
        static let now = dateformatter.string(from: ts)
        static let hash = md5(inputString: now + MarvelprivateKey + MarvelAPIKey)
    }
}
