//
//  ComicTableViewCell.swift
//  FindYourComic
//
//  Created by Marissa Kasenchak on 4/30/19.
//  Copyright © 2019 Marissa Kasenchak. All rights reserved.
//

import UIKit

class ComicTableViewCell: UITableViewCell {

    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var IssueLabel: UILabel!
    @IBOutlet weak var ComicImage: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
