//
//  MyComicModel.swift
//  FindYourComic
//
//  Created by Marissa Kasenchak on 4/29/19.
//  Copyright © 2019 Marissa Kasenchak. All rights reserved.
//

import Foundation
import UIKit
class myComicModel{
    var theCharacter: Array<Character>?
    var theComic: Array<Comic>?
    
   private func generateCharacterURL()->URL {
    let baseURL = "https://gateway.marvel.com:443/v1/public/characters"
    let limit = "100"
    let dateformatter = DateFormatter()
    let now = dateformatter.string(from: GlobalConstants.APIKey.ts)
    let limiturl = baseURL + "?limit=" + limit
    let keyurl = limiturl + "&ts=" + now + "&apikey=" + GlobalConstants.APIKey.MarvelAPIKey
    let url = keyurl + "&hash=" + GlobalConstants.APIKey.hash!
    let urlComponents = URLComponents(string: url)!
        print(urlComponents.string!)
        return urlComponents.url!
    }
    
    private func generateComicURL(id: Int)->URL {
        let baseURL = "https://gateway.marvel.com:443/v1/public/characters/"
        let stringid = String(id)
        let thebaseURL = baseURL + stringid + "/comics"
        let limit = "100"
        let dateformatter = DateFormatter()
        let now = dateformatter.string(from: GlobalConstants.APIKey.ts)
        let limiturl = thebaseURL + "?limit=" + limit
        let keyurl = limiturl + "&ts=" + now + "&apikey=" + GlobalConstants.APIKey.MarvelAPIKey
        let url = keyurl + "&hash=" + GlobalConstants.APIKey.hash!
        let urlComponents = URLComponents(string: url)!
        print(urlComponents.string!)
        return urlComponents.url!
    }
    
    func getCharacterData(url: URL, completionHandler: (()->())?) {
            // 2. retrieve the data
            let session = URLSession(configuration: .ephemeral)
            let task = session.dataTask(with: url) {
                // completion handler using trailing closure syntax
                (data, response, error) in
                // write some code here
                var aCharacterArray = Array<Character>()
                 if let actualData = data,
                    let parsedData = try? JSON(data: actualData) {
                    let theCharacters = parsedData["data"]
                    let theRealCharacters = theCharacters["results"]
                    //let thePictures = theCharacters["thumbnail"]
                    for (_, aCharacter) in theRealCharacters {
                        if let theid = aCharacter["id"].int,
                            let thename = aCharacter["name"].string,
                            let thedescription = aCharacter["description"].string,
                            let thepath = aCharacter["thumbnail"]["path"].string,
                            let theextension = aCharacter["thumbnail"]["extension"].string
                        {
                         //   for(_, aPicture) in thePictures {
                            //    if let thepath = aPicture["path"].string,
                            //        let theextension = aPicture["extension"].string
                            //    {
                            // 4. fill my array of FlickPictures with the data from (3)
                            let theCharacterArray = Character(
                                id: theid,
                                name: thename,
                                description: thedescription,
                                path: thepath,
                                ext: theextension)
                            aCharacterArray.append(theCharacterArray)
                        }
                         //   }
                       // }
                    }
                    
                    self.theCharacter = aCharacterArray
                }
                // If there is a completionHandler, dispatch it to the main thread
                DispatchQueue.main.async {
                    completionHandler?()
                }
                }
                task.resume()
            }   // End of Closure for session.dataTask()
    
    func getComicData(url: URL, completionHandler: (()->())?) {
        // 2. retrieve the data
        let session = URLSession(configuration: .ephemeral)
        let task = session.dataTask(with: url) {
            // completion handler using trailing closure syntax
            (data, response, error) in
            // write some code here
            var aComicArray = Array<Comic>()
            if let actualData = data,
                let parsedData = try? JSON(data: actualData) {
                let theComics = parsedData["data"]
                let theRealComics = theComics["results"]
               // let thePictures = theComics["thumbnail"]
                for (_, aComic) in theRealComics {
                    if let thetitle = aComic["title"].string,
                        let theissuenumber = aComic["issueNumber"].int,
                        let thedescription = aComic["description"].string,
                        let theisbn = aComic["isbn"].string,
                        let thepath = aComic["thumbnail"]["path"].string,
                        let theextension = aComic["thumbnail"]["extension"].string
                    {
                  //  for(_, aPicture) in thePictures {
                  //      if let thepath = aPicture["path"].string,
                  //          let theextension = aPicture["extension"].string
                  //  {
                        var issueasstring = String(theissuenumber)
                        // 4. fill my array of FlickPictures with the data from (3)
                        let theComicArray = Comic(
                            title: thetitle,
                            issuenumber: issueasstring,
                            description: thedescription,
                            isbn: theisbn,
                            path: thepath,
                            ext: theextension)
                        aComicArray.append(theComicArray)
                    }
                   // }
                   // }
                }
                
                self.theComic = aComicArray
            }
            // If there is a completionHandler, dispatch it to the main thread
            DispatchQueue.main.async {
                completionHandler?()
            }
        }
            task.resume()
    }   // End of Closure for session.dataTask()
    
func getCharacters(completionHandler: (()->())? = nil) {
    // 1. generate a URL to get the data
    let theURL = generateCharacterURL()
    getCharacterData(url: theURL, completionHandler: completionHandler)
}
    
    func getAllComics(id: Int, completionHandler: (()->())? = nil) {
        // 1. generate a URL to get the data
        let theURL = generateComicURL(id: id)
        getComicData(url: theURL, completionHandler: completionHandler)
    }
    func getCharacterCount()->Int {
        return theCharacter?.count ?? 0
    }
    
    func getComicCount()->Int {
        return theComic?.count ?? 0
    }
    
    init(){
        // where there's a memory warning, call proper method
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(receivedMemoryWarning),
            name: UIApplication.didReceiveMemoryWarningNotification,
            object: nil)
    }
    
    deinit {
        // cancel all of our subscriptions. We're going to Fla for the winter
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: internal methods
    // clean up my photos to reduce memory footprint
    @objc func receivedMemoryWarning(){
        if nil != theCharacter,
            nil != theComic {
            for pic in theCharacter! {
                pic.thumbnail = nil
                pic.bigPicture = nil
            }
            for thepic in theComic! {
                thepic.thumbnail = nil
                thepic.bigPicture = nil
            }
        }
    }
}
