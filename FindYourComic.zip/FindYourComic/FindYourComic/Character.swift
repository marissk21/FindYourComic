//
//  CharacterJSON.swift
//  FindYourComic
//
//  Created by Marissa Kasenchak on 5/2/19.
//  Copyright © 2019 Marissa Kasenchak. All rights reserved.
//
import UIKit
import Foundation

class Character {
    var id: Int
    var name: String
    var description: String
    var thumbnail: UIImage?
    var bigPicture: UIImage?
    var path: String
    var ext: String
    init(id: Int,
        name: String,
        description: String,
        path: String,
        ext: String){
        self.id = id
        self.name = name
        self.description = description
        self.path = path
        self.ext = ext
    }
    func getThumbnail(completionHandler: (()->())? = nil)->UIImage? {
        // 1. if the thumbnail exists, return it.
        if thumbnail != nil {
            return thumbnail
        }
        // 2. if the thumbnail is blank
        //      (a) try to make a data task
        let url = path + "/standard_medium." + ext
        let theurl = URL(string: url)
        print(url)
        let session = URLSession(configuration: .ephemeral)
        let task = session.dataTask(with: theurl!) {
            (data, response, error) in
            //      (b) get the tn data,
            if let actualError = error {
                print("Got an error in \(#file), line \(actualError)")
            } else if let actualResponse = response,let actualData = data,
                let actualImage = UIImage(data: actualData) {
                //      (c) create a UIImage,
                //      (d) set the TN
                self.thumbnail = actualImage
                //      (e) and call the CH
                // If there is a completionHandler, dispatch it to the main thread
                DispatchQueue.main.async {
                    completionHandler?()
                }
            }
        } // completionHandler end
        task.resume()
        return thumbnail
    }
    func getbigPicture(completionHandler: (()->())? = nil)->UIImage? {
        // 1. if the thumbnail exists, return it.
        if bigPicture != nil {
            return bigPicture
        }
        //      (a) try to make a data task
        let url = path + "/portrait_medium." + ext
        let theurl = URL(string: url)
        print(url)
        let session = URLSession(configuration: .ephemeral)
        let task = session.dataTask(with: theurl!) {
            (data, response, error) in
            //      (b) get the tn data,
            if let actualError = error {
                print("Got an error in \(#file), line \(actualError)")
            } else if let actualResponse = response,let actualData = data,
                let actualImage = UIImage(data: actualData) {
                //      (c) create a UIImage,
                //      (d) set the TN
                self.bigPicture = actualImage
                //      (e) and call the CH
                // If there is a completionHandler, dispatch it to the main thread
                DispatchQueue.main.async {
                    completionHandler?()
                }
            }
        } // completionHandler end
        task.resume()
        sleep(3)
        return bigPicture
    }
}
