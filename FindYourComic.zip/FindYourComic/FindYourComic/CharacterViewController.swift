//
//  CharacterViewController.swift
//  FindYourComic
//
//  Created by Marissa Kasenchak on 5/2/19.
//  Copyright © 2019 Marissa Kasenchak. All rights reserved.
//

import UIKit

class CharacterViewController: UIViewController {
    var theCharacter: Character?
    var myModel = myComicModel()
    var row: Int!
    @IBOutlet weak var theCharacterImage: UIImageView!
    @IBOutlet weak var theName: UILabel!
    @IBOutlet weak var theDescription: UILabel!
    @IBAction func searchComics(_ sender: Any) {
        performSegue(withIdentifier: "showcomics", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        theName.text = theCharacter?.name
        theDescription.text = theCharacter?.description
        theCharacterImage.image = theCharacter?.getbigPicture()
        // Do any additional setup after loading the view.
    }
    

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        if segue.identifier == "showcomics"{
            if let vc: ComicTableViewController = segue.destination as? ComicTableViewController,
                let theid = theCharacter?.id {
                    vc.id = theid
                
        }
        }
}
}
